"use strict";
(() => {
var exports = {};
exports.id = 419;
exports.ids = [419];
exports.modules = {

/***/ 744:
/***/ ((module) => {

module.exports = require("mysql");

/***/ }),

/***/ 762:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ tarefas)
/* harmony export */ });
var mysql = __webpack_require__(744);
var con = mysql.createConnection({
    host: "sql10.freesqldatabase.com",
    database: "sql10453712",
    user: "sql10453712",
    password: "hcjMA2wTW6"
});
var tarefasResultado = [];
con.connect(function(err1) {
    if (err1) throw err1;
    con.query("SELECT NOME, DESCRICAO, FINALIZADA, (SELECT NOME FROM USUARIO U WHERE U.ID = T.USUARIO) NOMEUSUARIO, (SELECT NOME FROM TIMES TI WHERE TI.ID = T.TIME) NOMETIME FROM TAREFA T", function(err, result, fields) {
        if (err) throw err;
        tarefasResultado = result;
    });
});
function tarefas(request, response) {
    const listaTarefas = [];
    response.json({
        listaTarefas: tarefasResultado
    });
};


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(762));
module.exports = __webpack_exports__;

})();